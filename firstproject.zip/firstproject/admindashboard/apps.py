from django.apps import AppConfig


class AdmindashboardConfig(AppConfig):
    name = 'admindashboard'
